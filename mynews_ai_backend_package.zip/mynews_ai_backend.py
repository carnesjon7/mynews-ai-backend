
from flask import Flask, request, jsonify
from supabase_memory_module import save_memory, get_memory

app = Flask(__name__)

@app.route("/mynews", methods=["POST"])
def mynews():
    data = request.get_json()

    user_id = data.get("user_id")
    preferences = data.get("preferences", {})

    # Retrieve previous memory if any
    memory = get_memory(user_id, "MyNews.AI")
    if not memory:
        memory = {
            "topics": ["world", "technology"],
            "tone": "neutral",
            "region": "global"
        }

    # Use new preferences if provided
    updated_memory = {
        "topics": preferences.get("topics", memory["topics"]),
        "tone": preferences.get("tone", memory["tone"]),
        "region": preferences.get("region", memory["region"])
    }

    # Generate mock news output
    output = f"📰 Here is your {updated_memory['tone']} news for {updated_memory['region']} on {', '.join(updated_memory['topics'])}."

    # Save updated memory
    save_memory(user_id, "MyNews.AI", updated_memory)

    return jsonify({ "output": output })

if __name__ == "__main__":
    app.run(debug=True)
